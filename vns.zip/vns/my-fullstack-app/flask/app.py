import os
from flask import Flask, render_template, request, redirect, url_for, flash, session
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename
from pymongo import MongoClient
from bson.objectid import ObjectId
from datetime import datetime, timedelta
from pymongo.server_api import ServerApi

app = Flask(__name__)
app.secret_key = 'your_secret_key_here'  # For flash messages and session management
app.permanent_session_lifetime = timedelta(minutes=30)  # Set session timeout to 30 minutes

# Connect to MongoDB
client = MongoClient('mongodb+srv://mayanksharma12662:root@mayank.chjb6.mongodb.net/?retryWrites=true&w=majority&appName=Mayank')
db = client['event_management']  # Database name
users_collection = db['users']  # Users collection
events_collection = db['events']  # Events collection

@app.route('/')
def home():
    return render_template('home.html')

@app.route('/signup', methods=['GET', 'POST'])
def signup():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        email = request.form['email']
        role = request.form['role']  # Either 'admin' or 'employee'

        # Check if username already exists in MongoDB
        if users_collection.find_one({'username': username}):
            flash('Username already exists!', 'danger')
        else:
            hashed_password = generate_password_hash(password)
            users_collection.insert_one({
                'username': username,
                'password': hashed_password,
                'email': email,
                'role': role
            })
            flash('Sign up successful! You can now log in.', 'success')
            return redirect(url_for('login'))

    return render_template('signup.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']

        # Fetch user from MongoDB
        user = users_collection.find_one({'username': username})

        if not user:
            flash('Username does not exist!', 'danger')
        else:
            if check_password_hash(user['password'], password):
                session['username'] = username
                session['role'] = user['role'].lower()

                # Redirect to the respective dashboard
                if session['role'] == 'admin':
                    return redirect(url_for('admin_dashboard'))
                elif session['role'] == 'employee':
                    return redirect(url_for('employee_dashboard'))
            else:
                flash('Incorrect password!', 'danger')

    return render_template('login.html')

@app.route('/admin-dashboard')
def admin_dashboard():
    if 'username' not in session or session.get('role') != 'admin':
        flash('Access denied!', 'danger')
        return redirect(url_for('login'))

    return render_template('admin_dashboard.html')

@app.route('/employee-dashboard')
def employee_dashboard():
    if 'username' not in session or session.get('role') != 'employee':
        flash('Access denied!', 'danger')
        return redirect(url_for('login'))

    return render_template('employee_dashboard.html')

@app.route('/show-event')
def show_event():
    if 'username' not in session or session.get('role') != 'employee':
        flash('Access denied!', 'danger')
        return redirect(url_for('login'))

    events = list(events_collection.find())  # Fetch all events
    return render_template('show_event.html', events=events)

@app.route('/interested/<event_id>', methods=['POST'])
def interested_in_event(event_id):
    if 'username' not in session or session.get('role') != 'employee':
        flash('Access denied!', 'danger')
        return redirect(url_for('login'))

    event = events_collection.find_one({'_id': ObjectId(event_id)})
    if not event:
        flash('Event not found!', 'danger')
        return redirect(url_for('show_event'))

    # Add a notification for the admin
    notification = {
        'message': f"{session['username']} is interested in the event: {event['name']}",
        'from': session['username'],
        'timestamp': datetime.now(),
        'to_role': 'admin'
    }
    db['notifications'].insert_one(notification)

    flash('Your interest has been sent to the admin!', 'success')
    return redirect(url_for('show_event'))

@app.route('/add-event', methods=['GET', 'POST'])
def addEvent():
    if 'username' not in session or session.get('role') != 'admin':
        flash('Access denied!', 'danger')
        return redirect(url_for('login'))

    if request.method == 'POST':
        # Retrieve form data
        event_name = request.form.get('event_name')
        event_description = request.form.get('event_description')
        event_date = request.form.get('event_date')
        event_time = request.form.get('event_time')
        event_location = request.form.get('event_location')

        # Validate required fields
        if not event_name or not event_description or not event_date or not event_time or not event_location:
            flash('All fields are required!', 'danger')
            return render_template('addEvent.html')

        # Combine event date and time
        event_datetime = datetime.strptime(f'{event_date} {event_time}', '%Y-%m-%d %H:%M')

        # Save the event to MongoDB
        try:
            event = {
                'name': event_name,
                'description': event_description,
                'datetime': event_datetime,  # Save as a single datetime field
                'location': event_location,
                'created_by': session['username'],  # Log the admin who created it
                'created_at': datetime.now()  # Add a timestamp
            }
            events_collection.insert_one(event)  # Save to events collection
            flash('Event added successfully!', 'success')
            return redirect(url_for('admin_dashboard'))
        except Exception as e:
            flash(f'An error occurred while adding the event: {e}', 'danger')

    # Render the Add Event page for GET requests
    return render_template('addEvent.html')

@app.route('/edit-profile', methods=['GET', 'POST'])
def edit_profile():
    if 'username' not in session:
        flash('Please log in first!', 'danger')
        return redirect(url_for('login'))
    
    # Fetch user data from MongoDB
    user = users_collection.find_one({'username': session['username']})
    
    if request.method == 'POST':
        name = request.form['name']
        email = request.form['email']
        profile_picture = request.files['profile_picture']
        
        # Update profile picture if present
        if profile_picture:
            filename = secure_filename(profile_picture.filename)
            profile_picture.save(os.path.join('static/uploads', filename))  # Save the image

        # Update user data in the database
        users_collection.update_one(
            {'username': session['username']},
            {'$set': {'name': name, 'email': email, 'profile_picture': filename if profile_picture else user.get('profile_picture')}}
        )

        flash('Profile updated successfully!', 'success')
        return redirect(url_for('employee_dashboard'))  # Redirect to the dashboard after update
    
    return render_template('edit_profile.html', user=user)

@app.route('/notifications')
def notifications():
    if 'username' not in session:
        flash('Access denied!', 'danger')
        return redirect(url_for('login'))

    # Fetch notifications based on role
    user_role = session.get('role')
    notifications = list(db['notifications'].find({'to_role': user_role}))
    return render_template('notification.html', notifications=notifications)

@app.route('/logout')
def logout():
    session.pop('username', None)
    session.pop('role', None)
    flash('You have been logged out.', 'info')
    return redirect(url_for('login'))

if __name__ == '__main__':
    app.run(debug=True)
